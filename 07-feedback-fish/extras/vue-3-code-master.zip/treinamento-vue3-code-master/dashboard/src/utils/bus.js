import Emitter from 'tiny-emitter'

export default new Emitter()
